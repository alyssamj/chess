package chess;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class PieceMoveCalculator {

    private final ChessBoard board;
    private final ChessPosition currentPosition;
    private final ChessPiece piece;
    Collection<ChessMove> myMoves = new ArrayList<>();

    public PieceMoveCalculator(ChessBoard board, ChessPosition currentPosition, ChessPiece piece) {
        this.board = board;
        this.currentPosition = currentPosition;
        this.piece = piece;
    }
    public Collection<ChessMove> returnMoves() {
        switch (piece.getPieceType()) {
            case ROOK:
                Rook myRook = new Rook();
                return myRook.getPossibleRookMoves();
            case BISHOP:
                Bishop myBishop = new Bishop();
                return myBishop.getPossibleBishopMoves();
            case QUEEN:
                Queen myQueen = new Queen();
                return myQueen.getPossibleQueenMoves();
            case KING:
                King myKing = new King();
                return myKing.getPossibleKingMoves();
            case PAWN:
                Pawn myPawn = new Pawn();
                return myPawn.getPossiblePawnMoves();
            case KNIGHT:
                Knight myKnight = new Knight();
                return myKnight.getPossibleKnightMoves();
            default:
                return Collections.EMPTY_LIST;
        }
    }
    private class Pawn {
        private Pawn() {}

        private Collection<ChessMove> getPossiblePawnMoves() {
            Collection<ChessMove> possiblePawnMoves = new ArrayList<>();
            int row = currentPosition.getRow();
            int col = currentPosition.getColumn();
            ArrayList<ChessPiece.PieceType> promotionTypes = new ArrayList<>();
            promotionTypes.add(ChessPiece.PieceType.QUEEN);
            promotionTypes.add(ChessPiece.PieceType.ROOK);
            promotionTypes.add(ChessPiece.PieceType.BISHOP);
            promotionTypes.add(ChessPiece.PieceType.KNIGHT);

            if (piece.getTeamColor() == ChessGame.TeamColor.WHITE) {
                ChessPosition newSpot = new ChessPosition(row+1, col);
                ChessPosition attackSpotRight = new ChessPosition(row+1, col+1);
                ChessPosition attackSpotLeft = new ChessPosition(row+1, col-1);
                if (row == 2) {
                    if (board.getPiece(newSpot) == null) {
                        possiblePawnMoves.add(new ChessMove(currentPosition, newSpot, null));
                        ChessPosition secondSpot = new ChessPosition(row+2, col);
                        if (board.getPiece(secondSpot) == null) {
                            possiblePawnMoves.add(new ChessMove(currentPosition, secondSpot, null));
                        }
                    }
                    if (board.getPiece(attackSpotLeft) == null) {

                    } else {
                       if (board.getPiece(attackSpotLeft).getTeamColor() != piece.getTeamColor()) {
                           possiblePawnMoves.add(new ChessMove(currentPosition, attackSpotLeft, null));
                       }
                    }
                    if (board.getPiece(attackSpotRight) == null) {}
                    else {
                        if (board.getPiece(attackSpotRight).getTeamColor() != piece.getTeamColor()) {
                            possiblePawnMoves.add(new ChessMove(currentPosition, attackSpotRight, null));
                        }
                    }
                }
                if (row >2 && row <7) {
                    if (board.getPiece(newSpot) == null) {
                        possiblePawnMoves.add(new ChessMove(currentPosition, newSpot, null));
                    }
                    if (board.getPiece(attackSpotLeft) == null) {

                    } else {
                        if (board.getPiece(attackSpotLeft).getTeamColor() != piece.getTeamColor()) {
                            possiblePawnMoves.add(new ChessMove(currentPosition, attackSpotLeft, null));
                        }
                    }
                    if (board.getPiece(attackSpotRight) == null) {}
                    else {
                        if (board.getPiece(attackSpotRight).getTeamColor() != piece.getTeamColor()) {
                            possiblePawnMoves.add(new ChessMove(currentPosition, attackSpotRight, null));
                        }
                    }
                }
                if (row == 7) {
                    if (board.getPiece(newSpot)==null) {
                        for (ChessPiece.PieceType pieceType : promotionTypes) {
                            possiblePawnMoves.add(new ChessMove(currentPosition, newSpot, pieceType));
                        }
                    }
                    if (board.getPiece(attackSpotLeft) == null) {

                    } else {
                        if (board.getPiece(attackSpotLeft).getTeamColor() != piece.getTeamColor()) {
                            for (ChessPiece.PieceType pieceType : promotionTypes) {
                                possiblePawnMoves.add(new ChessMove(currentPosition, attackSpotLeft, pieceType));
                            }
                        }
                    }
                    if (board.getPiece(attackSpotRight) == null) {

                    } else {
                        if (board.getPiece(attackSpotRight).getTeamColor() != piece.getTeamColor()) {
                            for (ChessPiece.PieceType pieceType : promotionTypes) {
                                possiblePawnMoves.add(new ChessMove(currentPosition, attackSpotLeft, pieceType));
                            }
                        }
                    }
                }
            } else {
                ChessPosition newSpot = new ChessPosition(row-1, col);
                ChessPosition attackSpotLeft = new ChessPosition(row-1, col-1);
                ChessPosition attackSpotRight = new ChessPosition(row-1, col+1);
                if (row == 7) {
                    if (board.getPiece(newSpot) == null) {
                        possiblePawnMoves.add(new ChessMove(currentPosition, newSpot, null));
                        ChessPosition secondSpot = new ChessPosition(row-2, col);
                        if (board.getPiece(secondSpot) == null) {
                            possiblePawnMoves.add(new ChessMove(currentPosition, secondSpot, null));
                        }
                    }
                    if (board.getPiece(attackSpotLeft) == null) {

                    } else {
                        if (board.getPiece(attackSpotLeft).getTeamColor() != piece.getTeamColor()) {
                            possiblePawnMoves.add(new ChessMove(currentPosition, attackSpotLeft, null));
                        }
                    }
                    if (board.getPiece(attackSpotRight) == null) {}
                    else {
                        if (board.getPiece(attackSpotRight).getTeamColor() != piece.getTeamColor()) {
                            possiblePawnMoves.add(new ChessMove(currentPosition, attackSpotRight, null));
                        }
                    }
                }
                if (row >2 && row <7) {
                    if (board.getPiece(newSpot) == null) {
                        possiblePawnMoves.add(new ChessMove(currentPosition, newSpot, null));
                    }
                    if (board.getPiece(attackSpotLeft) == null) {

                    } else {
                        if (board.getPiece(attackSpotLeft).getTeamColor() != piece.getTeamColor()) {
                            possiblePawnMoves.add(new ChessMove(currentPosition, attackSpotLeft, null));
                        }
                    }
                    if (board.getPiece(attackSpotRight) == null) {}
                    else {
                        if (board.getPiece(attackSpotRight).getTeamColor() != piece.getTeamColor()) {
                            possiblePawnMoves.add(new ChessMove(currentPosition, attackSpotRight, null));
                        }
                    }
                }
                if (row == 2) {
                    if (board.getPiece(newSpot)==null) {
                        for (ChessPiece.PieceType pieceType : promotionTypes) {
                            possiblePawnMoves.add(new ChessMove(currentPosition, newSpot, pieceType));
                        }
                    }
                    if (board.getPiece(attackSpotLeft) == null) {

                    } else {
                        if (board.getPiece(attackSpotLeft).getTeamColor() != piece.getTeamColor()) {
                            for (ChessPiece.PieceType pieceType : promotionTypes) {
                                possiblePawnMoves.add(new ChessMove(currentPosition, attackSpotLeft, pieceType));
                            }
                        }
                    }
                    if (board.getPiece(attackSpotRight) == null) {

                    } else {
                        if (board.getPiece(attackSpotRight).getTeamColor() != piece.getTeamColor()) {
                            for (ChessPiece.PieceType pieceType : promotionTypes) {
                                possiblePawnMoves.add(new ChessMove(currentPosition, attackSpotLeft, pieceType));
                            }
                        }
                    }
                }
            }
            return possiblePawnMoves;
        }
    }

    private class King {
        private King() {}

        private Collection<ChessMove> getPossibleKingMoves() {
            Collection<ChessMove> possibleKingMoves = new ArrayList<>();
            int row = currentPosition.getRow();
            int col = currentPosition.getColumn();

            ArrayList<ChessPosition> kingSpots = new ArrayList<>();
            kingSpots.add(new ChessPosition(row+1, col+1));
            kingSpots.add(new ChessPosition(row+1, col));
            kingSpots.add(new ChessPosition(row+1, col-1));
            kingSpots.add(new ChessPosition(row, col+1));
            kingSpots.add(new ChessPosition(row, col-1));
            kingSpots.add(new ChessPosition(row-1, col));
            kingSpots.add(new ChessPosition(row-1, col+1));
            kingSpots.add(new ChessPosition(row-1, col-1));
            for (ChessPosition position : kingSpots) {
                if (position.getRow() > 8 || position.getColumn() > 8 || position.getRow() < 1 || position.getColumn() <1) {
                    continue;
                }
                else if (board.getPiece(position) == null) {
                    possibleKingMoves.add(new ChessMove(currentPosition, position, null));
                } else {
                    if (board.getPiece(position).getTeamColor() != piece.getTeamColor()) {
                        possibleKingMoves.add(new ChessMove(currentPosition, position, null));
                    }
                }
            }
            return possibleKingMoves;
        }
    }
    private class Knight {
        private Knight() {}

        private Collection<ChessMove> getPossibleKnightMoves() {
            Collection<ChessMove> possibleKnightMoves = new ArrayList<>();
            int row = currentPosition.getRow();
            int col = currentPosition.getColumn();

            ArrayList<ChessPosition> knightSpots = new ArrayList<>();
            knightSpots.add(new ChessPosition(row+1, col+2));
            knightSpots.add(new ChessPosition(row+1, col-2));
            knightSpots.add(new ChessPosition(row+2, col-1));
            knightSpots.add(new ChessPosition(row+2, col+1));
            knightSpots.add(new ChessPosition(row-1, col-2));
            knightSpots.add(new ChessPosition(row-1, col+2));
            knightSpots.add(new ChessPosition(row-2, col+1));
            knightSpots.add(new ChessPosition(row-2, col-1));
            for (ChessPosition position : knightSpots) {
                if (position.getRow() > 8 || position.getColumn() > 8 || position.getRow() < 1 || position.getColumn() <1) {
                    continue;
                }
                else if (board.getPiece(position) == null) {
                    possibleKnightMoves.add(new ChessMove(currentPosition, position, null));
                } else {
                    if (board.getPiece(position).getTeamColor() != piece.getTeamColor()) {
                        possibleKnightMoves.add(new ChessMove(currentPosition, position, null));
                    }
                }
            }
            return possibleKnightMoves;
        }
    }

    private class Queen {
        private Queen() {}

        private Collection<ChessMove> getPossibleQueenMoves() {
            Collection<ChessMove> possibleQueenMoves = new ArrayList<>();
            Rook myRook = new Rook();
            Bishop myBishop = new Bishop();
            possibleQueenMoves.addAll(myRook.getPossibleRookMoves());
            possibleQueenMoves.addAll(myBishop.getPossibleBishopMoves());
            return possibleQueenMoves;

        }

    }

    private class Rook {

        private Rook() {}

        private Collection<ChessMove> getPossibleRookMoves() {
            Collection<ChessMove> possibleRookMoves = new ArrayList<>();
            int row = currentPosition.getRow();
            int col = currentPosition.getColumn();
            int i = 0;
            int j = 0;
            for (i = row + 1; i <= 8; i++) {
                ChessPosition newPosition = new ChessPosition(i, col);
                if (board.getPiece(newPosition) == null) {
                    possibleRookMoves.add(new ChessMove(currentPosition, newPosition, null));
                }
                if (board.getPiece(newPosition) != null) {
                    if (board.getPiece(newPosition).getTeamColor() != piece.getTeamColor()) {
                        possibleRookMoves.add(new ChessMove(currentPosition, newPosition, null));
                        break;
                    }
                    else {
                        break;
                    }
                }
            }
            for (j = col-1; j>=1; j--) {
                ChessPosition newPosition = new ChessPosition(row, j);
                if (board.getPiece(newPosition) == null) {
                    possibleRookMoves.add(new ChessMove(currentPosition, newPosition, null));
                } else {
                    if(board.getPiece(newPosition).getTeamColor() != piece.getTeamColor()) {
                        possibleRookMoves.add(new ChessMove(currentPosition, newPosition, null));
                        break;
                    } else {
                        break;
                    }
                }
            }
            for (i = row-1; i >=1; i--) {
                ChessPosition newPosition = new ChessPosition(i, col);
                if (board.getPiece(newPosition) == null) {
                    possibleRookMoves.add(new ChessMove(currentPosition, newPosition, null));
                } else {
                    if(board.getPiece(newPosition).getTeamColor() != piece.getTeamColor()) {
                        possibleRookMoves.add(new ChessMove(currentPosition, newPosition, null));
                        break;
                    } else {
                        break;
                    }
                }
            }
            for (j = col+1; j<=8; j++) {
                ChessPosition newPosition = new ChessPosition(row, j);
                if (board.getPiece(newPosition) == null) {
                    possibleRookMoves.add(new ChessMove(currentPosition, newPosition, null));
                } else {
                    if(board.getPiece(newPosition).getTeamColor() != piece.getTeamColor()) {
                        possibleRookMoves.add(new ChessMove(currentPosition, newPosition, null));
                        break;
                    } else {
                        break;
                    }
                }
            }
            return possibleRookMoves;
        }


    }
    private class Bishop {
        private Bishop() {}

        private Collection<ChessMove> getPossibleBishopMoves() {
            Collection<ChessMove> possibleBishopMoves = new ArrayList<>();
            int row = currentPosition.getRow();
            int col = currentPosition.getColumn();
            int i = 0;
            int j = 0;
            for (i = row + 1, j = col + 1; i <= 8 && j <= 8; i++, j++) {
                ChessPosition newPosition = new ChessPosition(i, j);
                if (board.getPiece(newPosition) == null) {
                    possibleBishopMoves.add(new ChessMove(currentPosition, newPosition, null));
                }
                if (board.getPiece(newPosition) != null) {
                    if (board.getPiece(newPosition).getTeamColor() != piece.getTeamColor()) {
                        possibleBishopMoves.add(new ChessMove(currentPosition, newPosition, null));
                        break;
                    }
                    else {
                        break;
                    }
                }
            }
            for (i = row+1, j = col-1; i <= 8 && j>=1; i++, j--) {
                ChessPosition newPosition = new ChessPosition(i, j);
                if (board.getPiece(newPosition) == null) {
                    possibleBishopMoves.add(new ChessMove(currentPosition, newPosition, null));
                } else {
                    if(board.getPiece(newPosition).getTeamColor() != piece.getTeamColor()) {
                        possibleBishopMoves.add(new ChessMove(currentPosition, newPosition, null));
                        break;
                    } else {
                        break;
                    }
                }
            }
            for (i = row-1, j = col-1; i >=1 && j>=1; i--, j--) {
                ChessPosition newPosition = new ChessPosition(i, j);
                if (board.getPiece(newPosition) == null) {
                    possibleBishopMoves.add(new ChessMove(currentPosition, newPosition, null));
                } else {
                    if(board.getPiece(newPosition).getTeamColor() != piece.getTeamColor()) {
                        possibleBishopMoves.add(new ChessMove(currentPosition, newPosition, null));
                        break;
                    } else {
                        break;
                    }
                }
            }
            for (i = row-1, j = col+1; i >=1 && j<=8; i--, j++) {
                ChessPosition newPosition = new ChessPosition(i, j);
                if (board.getPiece(newPosition) == null) {
                    possibleBishopMoves.add(new ChessMove(currentPosition, newPosition, null));
                } else {
                    if(board.getPiece(newPosition).getTeamColor() != piece.getTeamColor()) {
                        possibleBishopMoves.add(new ChessMove(currentPosition, newPosition, null));
                        break;
                    } else {
                        break;
                    }
                }
            }
            return possibleBishopMoves;
        }

    }
}
